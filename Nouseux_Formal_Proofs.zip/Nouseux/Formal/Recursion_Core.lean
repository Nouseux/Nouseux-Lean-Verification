import Mathlib.Tactic

namespace NouseuxRecursion

/-- Indicator function matching 1[·] in Version 5.0, Section 9. -/
def indicator (b : Bool) : ℝ := if b then 1 else 0

/-- Corrected recursive operator:
    N(t+1) = (1 - μ) * N(t) + η * 1[I_norm ∈ Ω_N] * P(t) * ‖O(t)‖ -/
def N_next (N P Onorm μ η : ℝ) (inBand : Bool) : ℝ :=
  (1 - μ) * N + η * indicator inBand * P * Onorm

theorem N_next_bounded
    (N P Onorm μ η : ℝ) (inBand : Bool)
    (hN : 0 ≤ N ∧ N ≤ 1)
    (hP : 0 ≤ P ∧ P ≤ 1)
    (hO : 0 ≤ Onorm ∧ Onorm ≤ 1)
    (hη0 : 0 ≤ η) (hημ : η ≤ μ) (hμ1 : μ ≤ 1) :
    0 ≤ N_next N P Onorm μ η inBand ∧
    N_next N P Onorm μ η inBand ≤ 1 := by
  obtain ⟨hN0, hN1⟩ := hN
  obtain ⟨hP0, hP1⟩ := hP
  obtain ⟨hO0, hO1⟩ := hO
  have hμ0 : 0 ≤ μ := le_trans hη0 hημ
  have h1μ0 : 0 ≤ 1 - μ := by linarith
  have hPO0 : 0 ≤ P * Onorm := mul_nonneg hP0 hO0
  have hPO1 : P * Onorm ≤ 1 := by nlinarith
  have hNbound : (1 - μ) * N ≤ 1 - μ := by
    calc (1 - μ) * N ≤ (1 - μ) * 1 := by
          apply mul_le_mul_of_nonneg_left hN1 h1μ0
      _ = 1 - μ := by ring
  have hNnonneg : 0 ≤ (1 - μ) * N := mul_nonneg h1μ0 hN0
  unfold N_next
  cases inBand with
  | false =>
      have hind : indicator false = 0 := by unfold indicator; simp
      rw [hind]
      constructor
      · nlinarith
      · nlinarith
  | true =>
      have hind : indicator true = 1 := by unfold indicator; simp
      rw [hind]
      have hPObound : η * 1 * P * Onorm ≤ μ := by
        have h1 : η * 1 * P * Onorm = η * (P * Onorm) := by ring
        rw [h1]
        calc η * (P * Onorm) ≤ η * 1 := by
              apply mul_le_mul_of_nonneg_left hPO1 hη0
          _ = η := by ring
          _ ≤ μ := hημ
      have hPOnonneg : 0 ≤ η * 1 * P * Onorm := by
        have h1 : η * 1 * P * Onorm = η * (P * Onorm) := by ring
        rw [h1]
        exact mul_nonneg hη0 hPO0
      constructor
      · nlinarith
      · nlinarith

end NouseuxRecursion
