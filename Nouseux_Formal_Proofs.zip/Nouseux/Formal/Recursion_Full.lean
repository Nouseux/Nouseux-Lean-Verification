import Nouseux.Formal.Recursion_Core

/- Ce module réexporte le socle défini dans Recursion_Core.
   Les définitions `indicator`, `N_next` et le théorème `N_next_bounded`
   sont désormais centralisées dans Recursion_Core.lean pour éviter
   toute duplication de déclaration entre modules. -/
