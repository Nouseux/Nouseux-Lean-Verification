import Nouseux.Formal.Recursion_Core

namespace NouseuxRecursion

theorem N_next_mono_P (N Onorm μ η : ℝ) (hη : 0 ≤ η) (hO : 0 ≤ Onorm) :
    Monotone (fun P => N_next N P Onorm μ η true) := by
  intro P₁ P₂ hP
  unfold N_next indicator
  simp only [if_true]
  nlinarith [mul_le_mul_of_nonneg_left hP (mul_nonneg hη hO)]

theorem N_next_mono_O (N P μ η : ℝ) (hη : 0 ≤ η) (hP : 0 ≤ P) :
    Monotone (fun Onorm => N_next N P Onorm μ η true) := by
  intro O₁ O₂ hO
  unfold N_next indicator
  simp only [if_true]
  nlinarith [mul_le_mul_of_nonneg_left hO (mul_nonneg hη hP)]

theorem N_next_mono_η (N P Onorm μ : ℝ) (hP : 0 ≤ P) (hO : 0 ≤ Onorm) :
    Monotone (fun η => N_next N P Onorm μ η true) := by
  intro η₁ η₂ hη
  unfold N_next indicator
  simp only [if_true]
  nlinarith [mul_le_mul_of_nonneg_right hη (mul_nonneg hP hO)]

end NouseuxRecursion
